<!DOCTYPE html>
<html>
    <head>
	    <title>TANISHA</title>
		<link href="home1.css" rel="stylesheet" type="text/css">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		
	</head>
	<body>
	    <header class="nav">
		<label class="logo"><img src="B.png"></label>
		<div class="image"><input type="text" placeholder="Search.."><i class="fa fa-search" aria-hidden="true"></i></div>
		<ul>
		    <li><a href="#Home">
		        <span class="icon"><i class="fa fa-home" aria-hidden="true"></i></span>
				<span class="text">Home</span>
			    </a>
			</li>
			<li><a href="#About_us">
		        <span class="icon"><i class="fa fa-info-circle" aria-hidden="true"></i></span>
				<span class="text">About</span>
			    </a>
			</li>
			<li><a href="#Contact_us">
		        <span class="icon"><i class="fa fa-user" aria-hidden="true"></i></span>
				<span class="text">Contact</span>
			    </a>
			</li>
			<div>
			     <a href="logout.php" class="login_button">Logout</a>
			</div>
			</ul>
			<div><input type="checkbox" id="check" name="check" value="check">
		<label for="check" id="chk"><i class="fa fa-bars" aria-hidden="true"></i></label>
		    </div>
		</header> 
		<section class="home" id="Home">
		    <div class="home_left_content">
			    <h1>Loop Buzz</h1>
				<h3>Music is the Medicine of Mind</h3>
				<p>There is Music in the Air, Music all Around us; The world is Full of it , and You Simply take as, Much as you Require.</p>
				<a href="#About_us" class="btn-box">MORE ABOUT WEBSITE</a>
				<a href="index.html" class="btn-box">GO TO OUR PLAYLIST</a>
		    </div>
			<div class="home_right_content">
			    <img src="G.png">
			</div>
		</section>
		<section class="about" id="About_us">
		    <div class="about_left_content">
			    <img src="G.png">
		    </div>
			<div class="about_right_content">
				<h2>About Website</h2>
				<h3>WHY WE LISTEN MUSIC?</h3>
				<p>Music can improve mood, decrease pain and <br>
				   anxiety, and facilitate opportunities for emotional<br> 
				   expression. Research suggests that music can benefit<br> 
				   our physical and mental health in numerous ways. Music <br>
				   therapy is used by our hospice and palliative care board<br>
				   certified music therapist to enhance conventional treatment <br>
				   for a variety of illnesses and disease processes – from anxiety,<br>
				   depression and stress, to the management of pain and enhancement of <br>
				   functioning after degenerative neurologic disorders.</p>
				<a href="#Contact_us" class="btn-box">Contact Us</a>
			</div>
		</section>
		<section class="contact" id="Contact_us">
		    <div class="contact-text">
				<h2>Contact us</h2>
				<h4>Lets work together</h4>
				<p>Music can improve mood, decrease pain and
				   anxiety, and facilitate opportunities for emotional
				   expression. Research suggests that music can benefit
				   our physical and mental health in numerous ways. Music 
				   therapy is used by our hospice and palliative care board
				   certified music therapist to enhance conventional treatment
				   functioning after degenerative neurologic disorders.</p>
				   <div class="contact-list">
				        <li><i class="fa fa-envelope" aria-hidden="true"></i>kaushaltanisha@gmail.com</li>
						<li><i class="fa fa-phone" aria-hidden="true"></i>9015296345</li>
				   </div>
				   <div class="contact-icons">
				        <a href="https://www.facebook.com/profile.php?id=100013988598500"><i class="fa fa-facebook" aria-hidden="true"></i></a>
						<a href="https://twitter.com/miishra1905?t=5GSL9t4GatQVatfuiDCVXw&s=08"><i class="fa fa-twitter" aria-hidden="true"></i></a>
						<a href="https://instagram.com/aryanmishra1905?igshid=MzRlODBiNWFlZA=="><i class="fa fa-instagram" aria-hidden="true"></i></a>
						<a href="https://www.linkedin.com/in/aryan-mishra-220436203"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
				   </div>
			</div>
			<div class="contact-form">
			<form action="<?php echo $_SERVER['PHP_SELF'];?>" method="POST">
			    <input type="text" name="uname" placeholder="ENTER YOUR NAME" required>
				<input type="email" name="emails" placeholder="ENTER YOUR EMAIL" required>
				<textarea name="text" id="" cols="40" rows="10" placeholder="ENTER YOUR RESPONSE"></textarea>
				<input type="submit" name="ook" value="submit" class="send">
			</form>
			<?php
			    if(isset($_REQUEST['ook']))
				{
					$username=$_REQUEST['uname'];
					$email=$_REQUEST['emails'];
					$textarea=$_REQUEST['text'];
					$con=mysqli_connect("localhost","root","","music_db");
					mysqli_query($con,"INSERT INTO contact_user(`username`, `email`, `textarea`) VALUES ('$username','$email','$textarea')");
					
					mysqli_close($con);
				}
			?>
			</div>
		</section>
		<script src="home1.js"></script>
	</body>
</html>