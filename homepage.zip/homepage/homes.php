<!DOCTYPE html>
<html>
    <head>
	    <title>TANISHA</title>
		<link href="homes.css" rel="stylesheet" type="text/css">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	</head>
	<body style="background-image:url('E.avif'); 
	background-repeat: no-repeat; 
	background-size:100% ;
	position:fixed;">
	    <header class="nav">
		<label class="logo"><img src="B.png"></label>
		<div class="image"><input type="text" placeholder="Search.."><i class="fa fa-search" aria-hidden="true"></i></div>
		<ul>
		    <li><a href="#Home">
		        <span class="icon"><i class="fa fa-home" aria-hidden="true"></i></span>
				<span class="text">Home</span>
			    </a>
			</li>
			<li><a href="#latest  ">
		        <span class="icon"><i class="fa fa-info-circle" aria-hidden="true"></i></span>
				<span class="text">About</span>
			    </a>
			</li>
			<li><a href="#">
		        <span class="icon"><i class="fa fa-user" aria-hidden="true"></i></span>
				<span class="text">Contact</span>
			    </a>
			</li>
			<div>
			     <a  class="login_button">Login</a>
			</div>
			</ul>
			<div><input type="checkbox" id="check" name="check" value="check">
		<label for="check" id="chk"><i class="fa fa-bars" aria-hidden="true"></i></label>
		    </div>
		</header>
		<div class="info">
		<div class="form">
		<span class="icon_close"><i class="fa fa-times" aria-hidden="true"></i></span>
		<?php include 'registerform.php';?>
		</div>
		</div>
		<script src="homes.js"></script>
	</body>
</html>